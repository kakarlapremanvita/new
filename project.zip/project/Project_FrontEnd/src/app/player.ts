export class Player {
    playerId?:number;
    playerName?:string;
    playerBiddingBudget?:number;
    playerTeamName?:string;


constructor()
{
}


}